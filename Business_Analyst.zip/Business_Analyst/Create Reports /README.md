Create Reports from a Database

Project Details:

You’re a business intelligence analyst for a wholesaler of various food products. You’re in charge of putting together analytics dashboards for management. They have requested that you focus on one area of the business and create a dashboard that provides various summary statistics related to that area.

Select one of the following areas. Create a presentation with visualizations that provides high level summary information about that area.

- Customers
- Suppliers
- Products
- Employees

Questions:
Q1) Leverling Vs Buchanan in number of orders 
Q2) How many orders to employees? 
Q3) How many suppliers have products ? 
Q4) What the highest products in price to company? 
Q5) What the total products price to region ‘LA’ ?


Tools:
  DB Browser for SQLite.
  Excel.
  PowerPoint.
