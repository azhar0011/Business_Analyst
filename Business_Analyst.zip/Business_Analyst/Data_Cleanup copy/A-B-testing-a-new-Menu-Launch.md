               A/B-testing-a-new-Menu-Launch

Project Details:

The Business Problem
Round Roasters is an upscale coffee chain with locations in the western United States of America. The past few years have resulted in stagnant growth at the coffee chain, and a new management team was put in place to reignite growth at their stores.

The first major growth initiative is to introduce gourmet sandwiches to the menu, along with limited wine offerings. The new management team believes that a television advertising campaign is crucial to drive people into the stores with these new offerings.

However, the television campaign will require a significant boost in the company’s marketing budget, with an unknown return on investment (ROI). Additionally, there is concern that current customers will not buy into the new menu offerings.


You’ve been asked to analyze the results of the experiment to determine whether the menu changes should be applied to all stores. The predicted impact to profitability should be enough to justify the increased marketing budget: at least 18% increase in profit growth compared to the comparative period while compared to the control stores; otherwise known as incremental lift. In the data, profit is represented in the gross_margin variable.

Data
round-roaster-stores.csv - This file contains store information for each Round Roaster store in the USA.
treatment-stores.csv - This file contains store information for each store that offered the new menu items.
round-roaster-transactions.zip - This file contains transaction level information for all of Round Roaster's stores

Tools:
Alteryx