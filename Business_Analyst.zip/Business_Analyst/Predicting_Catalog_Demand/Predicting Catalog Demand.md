                        Predicting-Catalog-Demand

Project Overview
You recently started working for a company that manufactures and sells high-end home goods.Last year it sent its first printed catalog and is now preparing to send the second catalog in the coming months. It now has 250  new customers from their mailing list who want to send the catalog to them.

Your manager has been asked to determine how much profit the company can expect from sending a catalog to these customers. You, the business analyst, are assigned to help your manager run the numbers. While fairly knowledgeable about data analysis, your manager is not very familiar with predictive models.
You’ve been asked to predict the expected profit from these 250 new customers. Management does not want to send the catalog out to these new customers unless the expected profit contribution exceeds $10,000.


Details
* The costs of printing and distributing is $6.50 per catalog.
* The average gross margin (price - cost) on all products sold through the catalog is 50%.
* Make sure to multiply your revenue by the gross margin first before you subtract out the $6.50 cost when calculating your profit.

Data
1. p1-customers.xlsx - This dataset includes the following information on about 2,300 customers. Important: You should build your model on this dataset and not p1-mailinglist.xlsx.
2. p1-mailinglist.xlsx - This dataset is the 250 customers that you need to predict sales. This is the list of customers that the company would send a catalog to.


The end of the project will be a decision yes based on all the steps that was worked on the project

Tools:
   Alteryx
